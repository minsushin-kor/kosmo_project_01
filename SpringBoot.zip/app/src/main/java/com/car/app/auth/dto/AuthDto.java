package com.car.app.auth.dto;

import lombok.*;

public class AuthDto {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MemberSignupRequest {
        private String loginId;
        private String email;
        private String password;
        private String name;
        private String phone;
        private String profileImageUrl;
        private Boolean hasCar;
        private String ownedCarImageUrl;
        private String ownedCarMake;
        private String ownedCarModel;
        private Double ownedCarOdometer;
        private Integer ownedCarYear;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CompanySignupRequest {
        private String loginId;
        private String businessNumber;
        private String name;
        private String masterEmail;
        private String password;
        private String address;
        private String phone;
        private String profileImageUrl;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LoginRequest {
        private String loginId;
        private String password;
        private String roleType; // 'MEMBER', 'COMPANY_MASTER', 'DEALER', 'ADMIN'
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LoginResponse {
        private String token;
        private String role;
        private String name;
        private String loginId;
    }
}
