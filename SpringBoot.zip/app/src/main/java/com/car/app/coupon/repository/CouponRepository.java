package com.car.app.coupon.repository;

import com.car.app.coupon.entity.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CouponRepository extends JpaRepository<Coupon, Long> {
    List<Coupon> findByDealerDealerId(Long dealerId);
    List<Coupon> findByCompanyCompanyId(Long companyId);
    boolean existsByUsedTransactionTransactionId(Long transactionId);
    List<Coupon> findByDealerDealerIdAndCouponTypeAndStatus(Long dealerId, String couponType, String status);
    boolean existsByDealerDealerIdAndCouponTypeAndStatus(Long dealerId, String couponType, String status);
    boolean existsByCompanyCompanyIdAndCouponTypeAndStatus(Long companyId, String couponType, String status);
    Optional<Coupon> findFirstByDealerDealerIdAndCouponTypeOrderByIssuedAtDesc(Long dealerId, String couponType);
}
