package com.car.app.car.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

public class CarDto {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateRequest {
        private Integer year;
        private String make;
        private String model;
        private String option;
        private String body;
        private String transmission;
        private String state;
        private Double condition;
        private Double odometer;
        private String color;
        private String interior;
        private Long sellingPrice;
        private List<ImageDto> images;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ImageDto {
        private String imageUrl;
        private Boolean isMain;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long carId;
        private Integer year;
        private String make;
        private String model;
        private String option;
        private String body;
        private String transmission;
        private String state;
        private Double condition;
        private Double odometer;
        private String color;
        private String interior;
        private Double mmr;
        private Long sellingPrice;
        private String status;
        private LocalDateTime createdAt;
        private String ownerType;
        private Long ownerId;
        private String ownerName;
        private String saleType;
        private String sellerType;
        private Long auctionId;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private String auctionStatus;
        private Long bidCount;
        private List<ImageDto> images;
        private Boolean goldenBadgeStatus;
    }
}
